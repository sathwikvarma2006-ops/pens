const mongoose = require('mongoose');

const internshipSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
    },
    finalDate: {
        type: Date,
        required: true,
    },
    slots: {
        type: Number,
        required: true,
    },
    price: {
        type: Number,
        required: false, // Price can be optional initially
        default: 0,
    },
});

module.exports = mongoose.model('Internship', internshipSchema);
