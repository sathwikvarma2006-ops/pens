const mongoose = require('mongoose');

const formSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  formType: {
    type: String,
    enum: ['Project', 'Internship'],
    required: true,
  },
  // Common fields
  email: { type: String, required: true },
  phoneNumber: { type: String },
  totalPrice: { type: Number },
  razorpay_payment_id: { type: String },

  // Project-specific fields
  fullName: { type: String },
  city: { type: String },
  state: { type: String },
  projectTitle: { type: String },
  projectDescription: { type: String },
  completedByDate: { type: Date },
  selectedPlan: { type: Object },
  selectedServices: { type: Object },
  file: { type: String }, // Store filename or path

  // Internship-specific fields
  internship: {
    name: { type: String },
    price: { type: Number },
    duration: { type: String },
  },
  primaryStudent: { type: Object },
  referrals: { type: Array },
  internshipStatus: {
    type: String,
    enum: ['Application Request', 'Internship Applications Accepted', 'done'],
    default: 'Application Request',
  },

  status: {
    type: String,
    enum: ['requested', 'request accepted', 'work started', 'project done and delivered'],
    default: 'requested',
  },

}, { timestamps: true });

module.exports = mongoose.model('Form', formSchema);
