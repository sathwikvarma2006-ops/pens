const express = require("express");
const multer = require("multer");
const { submitForm, submitInternshipForm, getMyForms, getUserCount, getAllForms, updateFormStatus, updateInternshipStatus, getAllInternshipForms } = require("../controllers/formController");
const auth = require('../middleware/authMiddleware');
const admin = require('../middleware/adminMiddleware');
const router = express.Router();

const upload = multer({ storage: multer.memoryStorage() });

router.post("/submit", auth, upload.single('file'), submitForm);
router.post("/submit-internship-form", auth, submitInternshipForm);
router.get("/me", auth, getMyForms);

// Admin routes
router.get("/admin/user-count", auth, admin, getUserCount);
router.get("/admin/all", auth, admin, getAllForms);
router.put("/admin/status/:id", auth, admin, updateFormStatus);
router.put("/admin/internship-status/:id", auth, admin, updateInternshipStatus);
router.get("/admin/internship-forms", auth, admin, getAllInternshipForms);

module.exports = router;
