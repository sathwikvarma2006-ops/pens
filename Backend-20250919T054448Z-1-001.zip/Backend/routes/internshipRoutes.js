const express = require('express');
const router = express.Router();
const { getInternships, createInternship, updateInternship, deleteInternship, setInternshipPrice, getInternshipByName } = require('../controllers/internshipController');
const auth = require('../middleware/authMiddleware');
const admin = require('../middleware/adminMiddleware');

// @route   GET api/internships
// @desc    Get all internships
// @access  Public
router.get('/', getInternships);

// @route   POST api/internships
// @desc    Create an internship
// @access  Admin
router.post('/', auth, admin, createInternship);

// @route   PUT api/internships/:id
// @desc    Update an internship
// @access  Admin
router.put('/:id', auth, admin, updateInternship);

// @route   PUT api/internships/:id/price
// @desc    Set price for an internship
// @access  Admin
router.put('/:id/price', auth, admin, setInternshipPrice);

// @route   DELETE api/internships/:id
// @desc    Delete an internship
// @access  Admin
router.delete('/:id', auth, admin, deleteInternship);

// @route   GET api/internships/:name
// @desc    Get internship by name
// @access  Public
router.get('/:name', getInternshipByName);

module.exports = router;
