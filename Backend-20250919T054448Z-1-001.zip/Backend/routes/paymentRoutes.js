const express = require("express");
const { createOrder, verifyPayment, getRazorpayKey, getMyPayments } = require("../controllers/paymentController");
const auth = require('../middleware/authMiddleware');
const router = express.Router();

router.get("/get-key", getRazorpayKey);
router.post("/create-order", auth, createOrder);
router.post("/verify", auth, verifyPayment);
router.get("/me", auth, getMyPayments);

module.exports = router;
