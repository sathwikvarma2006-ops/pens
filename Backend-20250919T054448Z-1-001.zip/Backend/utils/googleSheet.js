const { google } = require("googleapis");
const path = require("path");

const auth = new google.auth.GoogleAuth({
  keyFile: path.join(__dirname, "../credentials.json"),
  scopes: ["https://www.googleapis.com/auth/spreadsheets"],
});

const sheets = google.sheets({ version: "v4", auth });

async function addRowToSheet(sheetId, values, sheetName = "Sheet1") {
  try {
    console.log(`Appending to sheet: ${sheetId}, range: ${sheetName}`);
    await sheets.spreadsheets.values.append({
      spreadsheetId: sheetId,
      range: `${sheetName}`,
      valueInputOption: "USER_ENTERED",
      resource: { values: [values] },
    });
  } catch (error) {
    console.error(`Error appending to sheet: ${sheetId}`, error);
    throw error; // Re-throw the error to be caught by the controller
  }
}

module.exports = { addRowToSheet };

