const User = require('../models/User');

module.exports = async function (req, res, next) {
  try {
    // req.user is set by the auth middleware
    if (req.user.role !== 'admin') {
      return res.status(403).json({ msg: 'Access denied. Not an admin.' });
    }
    next();
  } catch (err) {
    console.error('something wrong with admin middleware');
    res.status(500).send('Server Error');
  }
};
