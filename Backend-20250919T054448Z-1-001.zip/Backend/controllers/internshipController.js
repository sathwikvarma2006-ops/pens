const Internship = require('../models/Internship');

// @desc    Get all internships
// @route   GET /api/internships
// @access  Public
exports.getInternships = async (req, res) => {
  try {
    const internships = await Internship.find().select('_id name finalDate slots price');
    res.json(internships);
  } catch (err) {
    res.status(500).json({ message: 'Failed to retrieve internships. Please try again later.' });
  }
};

// @desc    Create an internship
// @route   POST /api/internships
// @access  Admin
exports.createInternship = async (req, res) => {
  const { name, finalDate, slots, price } = req.body;

  try {
    const newInternship = new Internship({
      name,
      finalDate,
      slots,
      price,
    });

    const internship = await newInternship.save();
    res.json(internship);
  } catch (err) {
    res.status(500).json({ message: 'Failed to create internship. Please try again later.' });
  }
};

// @desc    Update an internship
// @route   PUT /api/internships/:id
// @access  Admin
exports.updateInternship = async (req, res) => {
  const { name, finalDate, slots, price } = req.body;

  try {
    let internship = await Internship.findById(req.params.id);

    if (!internship) {
      return res.status(404).json({ msg: 'Internship not found' });
    }

    internship.name = name;
    internship.finalDate = finalDate;
    internship.slots = slots;
    internship.price = price;

    internship = await internship.save();

    res.json(internship);
  } catch (err) {
    res.status(500).json({ message: 'Failed to update internship. Please try again later.' });
  }
};

// @desc    Set price for an internship
// @route   PUT /api/internships/:id/price
// @access  Admin
exports.setInternshipPrice = async (req, res) => {
  const { price } = req.body;

  try {
    let internship = await Internship.findById(req.params.id);

    if (!internship) {
      return res.status(404).json({ msg: 'Internship not found' });
    }

    internship.price = price;
    await internship.save();

    res.json(internship);
  } catch (err) {
    res.status(500).json({ message: 'Failed to set internship price. Please try again later.' });
  }
};

// @desc    Delete an internship
// @route   DELETE /api/internships/:id
// @access  Admin
exports.deleteInternship = async (req, res) => {
  try {
    let internship = await Internship.findById(req.params.id);

    if (!internship) {
      return res.status(404).json({ msg: 'Internship not found' });
    }

    await Internship.deleteOne({ _id: req.params.id });

    res.json({ msg: 'Internship removed' });
  } catch (err) {
    res.status(500).json({ message: 'Failed to delete internship. Please try again later.' });
  }
};

// @desc    Get internship by name
// @route   GET /api/internships/:name
// @access  Public
exports.getInternshipByName = async (req, res) => {
  try {
    console.log("Fetching internship by name:", req.params.name);
    const internship = await Internship.findOne({ name: req.params.name }).select('_id name finalDate slots price');
    if (!internship) {
      console.log("Internship not found for name:", req.params.name);
      return res.status(404).json({ msg: 'Internship not found' });
    }
    res.json(internship);
  } catch (err) {
    console.error("Error fetching internship by name:", err);
    res.status(500).json({ message: 'Failed to retrieve internship. Please try again later.' });
  }
};
