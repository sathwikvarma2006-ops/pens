const Razorpay = require("razorpay");
const crypto = require("crypto");
const Payment = require("../models/Payment");
const Form = require("../models/Form");
const Internship = require("../models/Internship"); // Import Internship model
const { addRowToSheet } = require("../utils/googleSheet");



const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID,
  key_secret: process.env.RAZORPAY_KEY_SECRET,
});

exports.getRazorpayKey = (req, res) => {
  res.json({ key: process.env.RAZORPAY_KEY_ID });
};

exports.createOrder = async (req, res) => {
  try {
    const { amount } = req.body;

    const options = {
      amount: amount * 100, // Use the amount directly
      currency: "INR",
      receipt: `receipt_${Date.now()}`,
    };

    const order = await razorpay.orders.create(options);

    // Save to MongoDB
    await Payment.create({ user: req.user.id, orderId: order.id, amount, status: "created" });

    res.json(order);
  } catch (err) {
    console.error("Error creating order:", err);
    res.status(500).json({ error: err.message });
  }
};

exports.verifyPayment = async (req, res) => {
  try {
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = req.body;

    const sign = razorpay_order_id + "|" + razorpay_payment_id;
    const expectedSign = crypto.createHmac("sha256", process.env.RAZORPAY_KEY_SECRET)
                               .update(sign.toString())
                               .digest("hex");

    if (razorpay_signature === expectedSign) {
      // Update DB
      await Payment.findOneAndUpdate(
        { orderId: razorpay_order_id, user: req.user.id },
        { paymentId: razorpay_payment_id, signature: razorpay_signature, status: "paid" }
      );

      res.json({ success: true, message: "Payment verified successfully" });
    } else {
      await Payment.findOneAndUpdate(
        { orderId: razorpay_order_id, user: req.user.id },
        { paymentId: razorpay_payment_id, signature: razorpay_signature, status: "failed" }
      );
      res.status(400).json({ success: false, message: "Invalid signature" });
    }
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getMyPayments = async (req, res) => {
  try {
    const payments = await Payment.find({ user: req.user.id }).sort({ createdAt: -1 }).lean();

    for (let payment of payments) {
      if (payment.paymentId) {
        const form = await Form.findOne({ razorpay_payment_id: payment.paymentId });
        if (form) {
          payment.formType = form.formType;
        }
      }
    }

    res.json(payments);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
};
