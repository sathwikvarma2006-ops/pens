const User = require('../models/User');
const { addRowToSheet } = require("../utils/googleSheet");
const Form = require('../models/Form');
const Internship = require('../models/Internship'); // Import Internship model

const {
  GET_IN_TOUCH_SHEET_ID,
  INTERNSHIP_SHEET_ID,
} = process.env;

exports.submitForm = async (req, res) => {
  try {
    // Check for existing, unfinished projects
    const existingProjects = await Form.find({ user: req.user.id, formType: 'Project' });
    const unfinishedProjects = existingProjects.filter(p => p.status !== 'project done and delivered');

    if (unfinishedProjects.length > 0) {
      return res.status(400).json({
        success: false,
        message: 'You already have a project in progress. Please wait for it to be completed before submitting a new one.'
      });
    }

    const {
        fullName,
        email,
        city,
        state,
        projectTitle,
        projectDescription,
        completedByDate,
        phoneNumber,
        selectedPlan,
        selectedServices,
        totalPrice,
        razorpay_payment_id
    } = req.body;

    const file = req.file;

    // Save to MongoDB
    const form = new Form({
      user: req.user.id,
      formType: 'Project',
      fullName,
      email,
      city,
      state,
      projectTitle,
      projectDescription,
      completedByDate,
      phoneNumber,
      selectedPlan: JSON.parse(selectedPlan),
      selectedServices: JSON.parse(selectedServices),
      totalPrice,
      razorpay_payment_id,
      file: file ? file.originalname : 'No file uploaded',
    });
    await form.save();

    // Add to Google Sheet
    const projectSheetValues = [
      new Date().toLocaleString(),
      fullName,
      email,
      phoneNumber,
      city,
      state,
      projectTitle,
      projectDescription,
      completedByDate,
      JSON.stringify(form.selectedPlan),
      JSON.stringify(form.selectedServices),
      totalPrice,
      razorpay_payment_id,
      file ? file.originalname : 'No file uploaded',
    ];
    try {
      await addRowToSheet(GET_IN_TOUCH_SHEET_ID, projectSheetValues, "Sheet1");
      console.log("Successfully added project order to Google Sheet.");
    } catch (sheetError) {
      console.error("Error adding project order to Google Sheet:", sheetError);
    }


    res.status(200).json({ success: true, message: "Form submitted successfully" });
  } catch (err) {
    res.status(500).json({ success: false, message: "Error submitting form", error: err.message });
  }
};

exports.submitInternshipForm = async (req, res) => {
  try {
    const {
        primaryStudent,
        referrals,
        internship: internshipName, // Renamed to internshipName to avoid conflict with model
        totalPrice,
        razorpay_payment_id
    } = req.body;

    // Find the internship plan details from the Internship model
    const internshipPlan = await Internship.findOne({ name: internshipName });

    if (!internshipPlan) {
      return res.status(404).json({
        success: false,
        message: 'Internship plan not found.'
      });
    }

    // Check if registration is past the final date
    if (internshipPlan.finalDate && new Date() > new Date(internshipPlan.finalDate)) {
      return res.status(400).json({
        success: false,
        message: 'Registration for this internship has closed.'
      });
    }

    // Check if max slots reached
    if (internshipPlan.slots) {
      const currentRegistrations = await Form.countDocuments({ formType: 'Internship', 'internship.name': internshipName });
      if (currentRegistrations >= internshipPlan.slots) {
        return res.status(400).json({
          success: false,
          message: 'All slots for this internship are filled.'
        });
      }
    }

    // Check for existing, unfinished internships for the user
    const unfinishedInternship = await Form.findOne({
      user: req.user.id,
      formType: 'Internship',
      internshipStatus: { $ne: 'done' }
    });

    if (unfinishedInternship) {
      return res.status(400).json({
        success: false,
        message: 'You already have an internship in progress. Please wait for it to be completed before submitting a new one.'
      });
    }

    // Save to MongoDB
    const form = new Form({
      user: req.user.id,
      formType: 'Internship',
      email: primaryStudent.email,
      phoneNumber: primaryStudent.phoneNumber,
      totalPrice,
      razorpay_payment_id,
      primaryStudent,
      internship: { // Store the internship plan details directly
        name: internshipPlan.name,
        price: internshipPlan.price,
        duration: internshipPlan.duration,
        // Add other relevant fields from internshipPlan if needed
      },
      referrals,
    });
    await form.save();

    // Add to Google Sheet
    const internshipSheetValues = [
      new Date().toLocaleString(),
      primaryStudent.fullName,
      primaryStudent.email,
      primaryStudent.phoneNumber,
      primaryStudent.college,
      primaryStudent.year,
      primaryStudent.branch,
      internshipPlan.name,
      totalPrice,
      razorpay_payment_id,
      referrals.join(', '),
    ];
    try {
      await addRowToSheet(INTERNSHIP_SHEET_ID, internshipSheetValues, "Sheet1");
      console.log("Successfully added internship registration to Google Sheet.");
    } catch (sheetError) {
      console.error("Error adding internship registration to Google Sheet:", sheetError);
    }

    res.status(200).json({ success: true, message: "Internship form submitted successfully" });
  } catch (err) {
    res.status(500).json({ success: false, message: "Error submitting internship form", error: err.message });
  }
};

exports.getMyForms = async (req, res) => {
  try {
    const forms = await Form.find({ user: req.user.id }).sort({ createdAt: -1 });
    res.json(forms);
  } catch (err) {
    res.status(500).json({ message: 'Failed to retrieve your forms. Please try again later.' });
  }
};

// Admin controllers
exports.getUserCount = async (req, res) => {
  try {
    const userCount = await User.countDocuments();
    res.json({ count: userCount });
  } catch (err) {
    res.status(500).json({ message: 'Failed to retrieve user count. Please try again later.' });
  }
};

exports.getAllForms = async (req, res) => {
  try {
    const forms = await Form.find().populate('user', 'name email').sort({ createdAt: -1 });
    res.json(forms);
  } catch (err) {
    res.status(500).json({ message: 'Failed to retrieve forms. Please try again later.' });
  }
};

exports.updateFormStatus = async (req, res) => {
  try {
    const { status } = req.body;
    const form = await Form.findById(req.params.id);

    if (!form) {
      return res.status(404).json({ msg: 'Form not found' });
    }

    form.status = status;
    await form.save();

    res.json(form);
  } catch (err) {
    res.status(500).json({ message: 'Failed to update form status. Please try again later.' });
  }
};

exports.updateInternshipStatus = async (req, res) => {
  try {
    const { internshipStatus } = req.body;
    const form = await Form.findById(req.params.id);

    if (!form) {
      return res.status(404).json({ msg: 'Form not found' });
    }

    form.internshipStatus = internshipStatus;
    await form.save();

    res.json(form);
  } catch (err) {
    res.status(500).json({ message: 'Failed to update internship status. Please try again later.' });
  }
};

exports.getAllInternshipForms = async (req, res) => {
  try {
    const forms = await Form.find({ formType: 'Internship' }).populate('user', 'name email').sort({ createdAt: -1 });
    res.json(forms);
  } catch (err) {
    res.status(500).json({ message: 'Failed to retrieve internship forms. Please try again later.' });
  }
};
